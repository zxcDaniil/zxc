<?php 
namespace app\models;

use Yii;
use yii\base\Model;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\helper\Url;
use yii\controller\SiteConstroller;


class Menu extends Model{
    public static function getMenu()
    {

         //$roles = Yii::$app->user->identity->userroles;
        
        if(Yii::$app->user->isGuest)
        {
            $menu = [
            ['label' => 'Войти', 'url' => ['/site/login']],
            ['label' => 'Регистрация', 'url' => ['/site/signup']],
            ];
            return $menu;
        }

        if(!Yii::$app->user->identity->userroles){
            $menu = [
            ['label' => Yii::$app->user->identity->username, 'url' => ['site/logout'], ['data-method' => 'POST' ]],
            ['label' => 'профиль', 'url' => ['/profile/view' , 'id' => Yii::$app->user->identity->id]],
            ];
        }

        if(in_array(User::ROLE_ADMIN,Yii::$app->user->identity->userroles)){
            $menu = [
            //['label' => 'фото', 'url' => ['/site']],
            ['label' => 'панель', 'url' => ['/admin']],
            ['label' => 'профиль', 'url' => ['/profile/view' , 'id' => Yii::$app->user->identity->id]],
            ['label' => Yii::$app->user->identity->username, 'url' => ['site/logout'], ['data-method' => 'POST' ]],
            ];
        }
        
        if(in_array(User::ROLE_MANAGER,Yii::$app->user->identity->userroles)){
            $menu = [
            ['label' => 'заказы', 'url' => ['/site']],
            ['label' => 'товары', 'url' => ['/site']],
            ['label' => 'профиль', 'url' => ['/profile/view' , 'id' => Yii::$app->user->identity->id]],
            ['label' => Yii::$app->user->identity->username, 'url' => ['site/logout'], ['data-method' => 'POST' ]],
            ];
        }

        
        $default = [
           // ['label' => 'Корзина', 'url' => ['#']],
        ];
      return ArrayHelper::merge($menu, $default);
    }
}